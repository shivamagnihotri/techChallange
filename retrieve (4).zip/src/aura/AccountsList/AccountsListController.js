({
	doInit : function(component, event, helper){
		helper.doInit(component);
	},
    showAccountDetail : function(component, event, helper){
        helper.showAccountDetail(component, event);
    },    
    loadAccount : function(component, event, helper) {
		helper.loadAccount(component);
	}    
})